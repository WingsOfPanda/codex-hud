// @exec: {"yield_time_ms": 95000, "max_output_tokens": 1000}
const deadline = Date.now() + 90000;
let result = await tools.exec_command({cmd: "# codex-plus-shell: foreground\n# codex-plus-advisor: mixed version result proof\n/data/liupan/codex-plus-build/release0165-plus049/native-arm/attempts/0.165.0-plus.0.4.9-aarch64-8cca6038b6953871/extracted/codex-plus-0.165.0-plus.0.4.9-aarch64-unknown-linux-gnu/bin/codex-plus run -- /data/liupan/codex-plus-build/release0165-plus049/native-arm/attempts/0.165.0-plus.0.4.9-aarch64-8cca6038b6953871/extracted/codex-plus-0.165.0-plus.0.4.9-aarch64-unknown-linux-gnu/bin/codex-plus advisor --brief 'Read only the explicitly attached fixture evidence and return the structured fixture verdict.' --host local --context-file '/tmp/r2/a45-cj4e4bl9/w/explicit context file.txt'", yield_time_ms: 250, max_output_tokens: 1000, login: false});
let log = result.output.match(/codex-plus log: (.+)/)?.[1];
let output = result.output;
while (result.session_id !== undefined && Date.now() < deadline) {
  result = await tools.write_stdin({session_id: result.session_id, chars: "", yield_time_ms: Math.min(300000, Math.max(1, deadline - Date.now())), max_output_tokens: 1000});
  output += result.output;
  log ??= output.match(/codex-plus log: (.+)/)?.[1];
  output = output.slice(-4000);
}
text({state: result.session_id === undefined ? "finished" : "budget_expired", exit_code: result.exit_code, session_id: result.session_id, log, output});
