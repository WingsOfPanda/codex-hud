import json,os,subprocess
from pathlib import Path
runtime='/tmp/r2/s-vcqm0o0s/package/bin/codex-plus-runtime'
ident='e83f2e17-e996-4d1e-80f5-642fa74016cc'
directory=Path('/tmp/r2/s-vcqm0o0s/work/goal-cleanup-recovery')
root=os.environ['CODEX_THREAD_ID']
def run(*args):
    p=subprocess.run([runtime,*args],capture_output=True,text=True,timeout=12)
    assert p.returncode == 0, (args,p.stdout,p.stderr)
    return json.loads(p.stdout)
s=run('goal','status','--thread',root,'--json')
turn=(s.get('binding') or {}).get('turn') or s['current_turn']['id']
binding=['--thread',root,'--id',s['goal']['id'],'--revision',str(s['goal']['revision']),
         '--input-epoch',str(s['input_epoch']),'--turn',turn]
run('goal','admit',*binding,'--json')
proof=directory/'callback-resolution.json'
proof.write_text(json.dumps(dict(root=root,id=ident,cleanup_verified=True,
    evidence='Private workload ended; false cleanup has no effects; resolver must verify exact process absence.')))
resolved=run('job','resolve','--id',ident,'--evidence',str(proof))
assert resolved['state']=='failed' and resolved['resolution']['cleanup_verified'] is True
run('goal','checkpoint',*binding,'--checkpoint',json.dumps(dict(disposition='complete',
    evidence=['fixture:known-exit-preserved-and-cleanup-verified-without-replay'])),'--json')
(directory/'callback-recovery-done').touch()
