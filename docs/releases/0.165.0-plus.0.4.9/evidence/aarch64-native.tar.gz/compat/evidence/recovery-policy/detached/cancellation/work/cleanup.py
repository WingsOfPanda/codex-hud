from pathlib import Path
Path('/tmp/r2/s-9b2fsry8/work/cleanup-done').write_text('clean\n')
