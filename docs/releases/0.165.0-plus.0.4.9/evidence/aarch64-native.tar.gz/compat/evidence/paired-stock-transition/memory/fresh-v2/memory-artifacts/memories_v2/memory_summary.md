v1

## User Profile
Private fixture

## User preferences
Deterministic

## General Tips
Keep evidence

## What's in Memory
memory-transition-v2
