memory-transition-v1 consolidated memory
