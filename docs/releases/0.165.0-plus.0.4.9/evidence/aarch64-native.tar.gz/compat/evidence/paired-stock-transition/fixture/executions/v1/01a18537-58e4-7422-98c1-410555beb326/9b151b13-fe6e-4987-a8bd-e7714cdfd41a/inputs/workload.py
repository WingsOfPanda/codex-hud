from pathlib import Path
import sys,time
p=Path(sys.argv[1])
with (p/'runs').open('a') as f: f.write('run\n')
print('started',flush=True)
end=time.monotonic()+25
while not (p/'release').exists() and time.monotonic()<end:
    print('progress',flush=True); time.sleep(.08)
assert (p/'release').exists(), 'fixture release timeout'
print('complete',flush=True)
