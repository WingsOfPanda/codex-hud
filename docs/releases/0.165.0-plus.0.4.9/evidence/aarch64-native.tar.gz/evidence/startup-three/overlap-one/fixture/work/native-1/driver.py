import json,subprocess,sys,time
from pathlib import Path
p=Path(sys.argv[1]); spec=json.loads((p/'spec.json').read_text())
import os;os.environ.update({'LD_PRELOAD': '/data/liupan/codex-plus-build/release0165-plus049/native-arm/attempts/0.165.0-plus.0.4.9-aarch64-8cca6038b6953871/evidence/startup-three/executor_reconcile_gate.so', 'DIAG_ROLE': 'launcher', 'DIAG_GATE': '/data/liupan/codex-plus-build/release0165-plus049/native-arm/attempts/0.165.0-plus.0.4.9-aarch64-8cca6038b6953871/evidence/startup-three/overlap-one', 'DIAG_MODE': 'overlap'});responses=[]; prepared={}
for index,operation in enumerate(spec['operations'],1):
    values={'{turn}':(p/'turn').read_text(),'{id}':prepared.get('id',''),
            '{digest}':prepared.get('review_digest','')}
    args=[values.get(str(arg),str(arg)) for arg in operation]
    result=subprocess.run([spec['runtime'],*args],capture_output=True,text=True,timeout=12)
    try: output=json.loads(result.stdout)
    except ValueError: output=None
    responses.append(dict(args=args,returncode=result.returncode,output=output,
                          stdout=result.stdout,stderr=result.stderr))
    if output and isinstance(output,dict) and 'review_digest' in output:
        prepared=output
    temporary=p/'responses.tmp'; temporary.write_text(json.dumps(responses)); temporary.replace(p/'responses.json')
    if spec.get('pause_after')==index:
        (p/'paused').touch(); end=time.monotonic()+20
        while not (p/'continue').exists() and time.monotonic()<end: time.sleep(.02)
        assert (p/'continue').exists(), 'native fixture continuation timeout'
(p/'done').touch()
print(json.dumps(responses))
