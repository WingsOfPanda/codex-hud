from pathlib import Path
Path('/tmp/ny/s-0t3u11g9/work/cleanup-done').write_text('clean\n')
